# Running the Server

This Challenge will require you to setup and run the application in this repository.

[Refer to the jQuery AJAX lecture notes for installing and running the server]  (https://github.com/kdszafranski/prime-ajax-intro)

These instructions will be the same for all of our node applications.
